// V0166: relevant, duration-filtered Freesound music with real API pagination.
const CATEGORIES={
 'news broadcast intro':['news broadcast music','news intro instrumental','breaking news theme','broadcast background instrumental','television news music'],
 'political documentary':['political documentary music','political tension music','news background music','documentary cinematic','suspense instrumental'],
 'sports energetic':['sports energetic music','sport instrumental','sports action background','sports highlights music','stadium energetic instrumental'],
 'epic orchestral':['epic orchestral music','heroic cinematic soundtrack'],
 'cinematic soundtrack':['cinematic soundtrack music','film score instrumental'],
 'action suspense':['action suspense music','thriller soundtrack'],
 'calm ambient':['calm ambient music','peaceful instrumental'],
 'sad emotional':['sad emotional music','melancholic piano music'],
 'upbeat energetic':['upbeat energetic music','motivational instrumental'],
 'dramatic tension':['dramatic tension music','suspense soundtrack'],
 'technology electronic':['technology electronic music','futuristic electronic soundtrack'],
 'documentary ambient':['documentary background music','documentary ambient soundtrack'],
 'police chase music':['police chase music','crime thriller soundtrack'],
 'crime thriller soundtrack':['crime thriller soundtrack','detective suspense music']
};

const IRANIAN=/[؀-ۿ]|\b(persian|iranian|bandari|bandari|iran|farsi|kurdi|kurdish|lori|luri)\b/i;
const IRANIAN_INTENT=/شاد\s*(بندری|ایرانی|جنوبی)|بندری|ایرانی|فارسی|جنوبی|کردی|لری|خواننده|پاپ\s*ایرانی|رقص\s*ایرانی/i;
const iranianTerms=q=>{
 const t=String(q).trim();
 if(/بندری|جنوبی/.test(t))return ['bandari persian dance','iranian bandari','persian southern music'];
 if(/کردی/.test(t))return ['kurdish dance music','kurdish traditional music'];
 if(/لری/.test(t))return ['luri iranian dance','lori persian folk music'];
 if(/شاد|رقص|عروسی/.test(t))return ['persian dance music','iranian party music','persian wedding music'];
 return ['persian music','iranian music',t];
};
const relevantIranian=t=>{
 const hay=[t.name,t.artist,t.description,(t.tags||[]).join(' ')].join(' ');
 return IRANIAN.test(hay);
};
const timeoutFetch=async(url,options={})=>{const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),10000);try{return await fetch(url,{...options,signal:controller.signal})}finally{clearTimeout(timer)}};
const normalize=s=>String(s||'').toLowerCase().replace(/[^a-z0-9 ]/g,' ');
const isMusic=t=>{const s=normalize([t.name,t.description,(t.tags||[]).join(' ')].join(' '));return !/\b(footsteps|gunshot|gun fire|door slam|siren only|beep|alarm only|voiceover|spoken|speech|sound effect|sfx|one shot|one shot sample|field recording)\b/.test(s)};
async function freesound(terms,page,limit){
 const key=process.env.FREESOUND_API_KEY;if(!key)return {data:[],total:0,available:false};
 const queries=[...new Set(terms.filter(Boolean))];
 const candidates=[];const seen=new Set();let count=0;let successful=0;
 // Use several related phrases when a narrow category returns no usable music.
 // Keep pagination at the provider level and never fabricate tracks.
 for(let i=0;i<Math.min(queries.length,5);i++){
  const url=new URL('https://freesound.org/apiv2/search/text/');
  url.searchParams.set('query',queries[i]);
  url.searchParams.set('fields','id,name,duration,previews,license,url,description,tags');
  url.searchParams.set('filter','duration:[20 TO 900]');
  url.searchParams.set('page_size',String(Math.min(150,Math.max(limit*2,48))));
  url.searchParams.set('page',String(page));
  try{
   const r=await timeoutFetch(url.toString(),{headers:{Authorization:'Token '+key,Accept:'application/json'}});
   if(!r.ok)continue;
   const json=await r.json();successful++;
   count=Math.max(count,Number(json.count)||0);
   for(const t of json.results||[]){
    if(!isMusic(t)||seen.has(t.id))continue;
    const mp3=t.previews?.['preview-hq-mp3']||t.previews?.['preview-lq-mp3'];
    if(!mp3||!/^https:\/\//.test(mp3))continue;
    seen.add(t.id);
    candidates.push({id:'freesound-'+t.id,name:t.name||'بدون عنوان',duration:Number(t.duration)||0,source:'Freesound',download_allowed:false,license:t.license||'',source_url:t.url||'https://freesound.org/s/'+t.id+'/',files:{mp3},is_premium:false});
   }
   // Collect across related searches to improve diversity; do not stop after the first full source.
  }catch(e){/* Try the next related phrase instead of returning zero. */}
 }
 return {data:candidates,total:null,available:successful>0,hasNext:candidates.length>=limit};
}

// Jamendo official public tracks API. Only advertise download for tracks allowed by provider.
async function jamendo(terms,page,limit){
 const id=process.env.JAMENDO_CLIENT_ID;
 if(!id)return {data:[],total:0,available:false};
 const queries=[...new Set(terms.filter(Boolean))].slice(0,5);
 const results=await Promise.allSettled(queries.map(async q=>{
  const url=new URL('https://api.jamendo.com/v3.0/tracks/');
  for(const [k,v] of Object.entries({client_id:id,format:'json',limit:String(Math.min(100,Math.max(limit*2,36))),offset:String((page-1)*Math.min(100,Math.max(limit*2,36))),search:q,audioformat:'mp32'}))url.searchParams.set(k,v);
  const r=await timeoutFetch(url.toString(),{headers:{Accept:'application/json'}});
  if(!r.ok)throw Error('Jamendo HTTP '+r.status);
  const j=await r.json();if(j.headers?.status!=='success')throw Error('Jamendo API error');
  return {total:Number(j.headers?.results_fullcount)||0,tracks:(j.results||[]).filter(t=>t.audio&&Number(t.duration)>=20).map(t=>({
   id:'jamendo-'+t.id,name:t.name||'موسیقی',duration:Number(t.duration)||0,source:'Jamendo',artist:t.artist_name||'',license:t.license_ccurl||'',source_url:t.shareurl||'',download_allowed:t.audiodownload_allowed===true||t.audiodownload_allowed==='true',files:{mp3:t.audio,download:t.audiodownload||''},is_premium:false
  }))};
 }));
 const good=results.filter(r=>r.status==='fulfilled').map(r=>r.value);
 const seen=new Set(),data=[];
 for(const result of good)for(const track of result.tracks)if(!seen.has(track.id)){seen.add(track.id);data.push(track)}
 return {data,total:null,available:good.length>0,hasNext:good.some(r=>r.tracks.length>=Math.min(100,Math.max(limit*2,36)))};
}

// Verify that the official Audius download endpoint actually serves audio.
// A metadata download flag alone is not sufficient. Fail closed on timeout/errors.
async function audiusDownloadVerified(id){
 const url='https://api.audius.co/v1/tracks/'+encodeURIComponent(id)+'/download';
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),6500);
 try{
  const r=await fetch(url,{method:'GET',headers:{Range:'bytes=0-2047',Accept:'audio/*,application/octet-stream'},signal:controller.signal,redirect:'follow'});
  const ct=(r.headers.get('content-type')||'').toLowerCase();
  const ok=r.ok && (ct.startsWith('audio/')||ct.includes('octet-stream')) && !ct.includes('json') && !ct.includes('html');
  if(r.body)await r.body.cancel().catch(()=>{});
  return ok;
 }catch{return false}finally{clearTimeout(timer)}
}
// Audius public read-only search; no key needed for the initial integration.
async function audius(terms,page,limit){
 const queries=[...new Set(terms.filter(Boolean))].slice(0,5);
 const batch=Math.min(50,Math.max(limit,24));
 const settled=await Promise.allSettled(queries.map(async term=>{
  const url=new URL('https://api.audius.co/v1/tracks/search');
  url.searchParams.set('query',term);url.searchParams.set('limit',String(batch));
  url.searchParams.set('offset',String((page-1)*batch));
  const response=await timeoutFetch(url.toString(),{headers:{Accept:'application/json'}});
  if(!response.ok)throw Error('Audius HTTP '+response.status);
  const json=await response.json();
  if(!Array.isArray(json.data))throw Error('Invalid Audius response');
  return json.data;
 }));
 const data=[],seen=new Set();let available=false,more=false;
 for(const result of settled){if(result.status!=='fulfilled')continue;available=true;
  if(result.value.length===batch)more=true;
  for(const t of result.value){
   const id=String(t.id||'');const stream=t.stream?.url;
   if(!id||seen.has(id)||!t.access?.stream||!t.is_streamable||!/^https:\/\//.test(stream||'')||Number(t.duration)<20||Number(t.duration)>900)continue;
   seen.add(id);
   // Only offer Audius tracks whose actual download endpoint passed an audio response check.
   if(!(t.access?.download===true && t.is_downloadable===true && !t.is_download_gated))continue;
   data.push({id:'audius-'+id,name:t.title||'موسیقی',artist:t.user?.name||'',duration:Number(t.duration)||0,source:'Audius',license:t.license||'',source_url:'https://audius.co'+(t.permalink||''),download_allowed:t.access?.download===true && t.is_downloadable===true && !t.is_download_gated,files:{mp3:stream,download:t.access?.download===true && t.is_downloadable===true && !t.is_download_gated ? 'https://api.audius.co/v1/tracks/'+encodeURIComponent(id)+'/download' : ''},is_premium:false});
  }
 }
 const checked=await Promise.all(data.map(async t=>({t,ok:await audiusDownloadVerified(t.id.slice(7))})));
 return {data:checked.filter(x=>x.ok).map(x=>x.t),available,hasNext:more};
}

async function existingMusic(terms,page,limit){
 const url=new URL('https://api.freetouse.com/v3/music/tracks/search');url.searchParams.set('query',terms[0]);url.searchParams.set('limit',String(limit));url.searchParams.set('page',String(page));
 try{const r=await timeoutFetch(url.toString(),{headers:{Accept:'application/json'}});if(!r.ok)return [];const j=await r.json();return (Array.isArray(j.data)?j.data:[]).filter(t=>t&&!t.is_premium&&t.files?.mp3&&Number(t.duration)>=30&&Number(t.duration)<=600)}catch{return []}
}
module.exports=async(req,res)=>{
 res.setHeader('Cache-Control','s-maxage=120, stale-while-revalidate=240');
 const q=String(req.query.q||'cinematic soundtrack').slice(0,100),iranian=IRANIAN_INTENT.test(q),terms=iranian?iranianTerms(q):(CATEGORIES[q]||[q, q+' music']);
 const page=Math.max(1,Math.min(200,parseInt(req.query.page,10)||1));
 const limit=[12,24,36].includes(Number(req.query.limit))?Number(req.query.limit):12;
 const [jm,au]=await Promise.allSettled([jamendo(terms,page,limit),audius(terms,page,limit)]);
 const jam=jm.status==='fulfilled'?jm.value:{data:[],total:0,available:false};
 const aud=au.status==='fulfilled'?au.value:{data:[],available:false,hasNext:false};
 // Download-only catalog: do not show tracks that cannot be downloaded legally.
 // Audius entries have already passed a real upstream audio-response check.
 // Jamendo is included only when its official metadata explicitly permits downloading.
 // Freesound previews and legacy streams are excluded: they do not establish full-track download rights.
 const selected=(iranian?[...jam.data,...aud.data]:[...aud.data,...jam.data])
   .filter(t=>t.download_allowed===true && /^https:\/\//.test(t.files?.download||''))
   .filter(t=>!iranian||relevantIranian(t));
 const data=[];const ids=new Set();
 for(const t of selected){const key=String(t.source)+'|'+String(t.id);if(ids.has(key))continue;ids.add(key);data.push(t);if(data.length>=limit)break}
 if(jm.status==='rejected'&&au.status==='rejected')return res.status(502).json({error:'ارتباط با منابع موزیک برقرار نشد'});
 // No source provides an exact, de-duplicated, download-verified total for this combined search.
 // Never report page size or unfiltered provider estimates as the total.
 // Provider pages may contain fewer eligible downloads; even a lower-bound count
 // across prior pages cannot be inferred without storing the actual prior results.
 const hasNext=Boolean(aud.hasNext||jam.hasNext);
 res.status(200).json({data,total:null,verifiedOnPage:data.length,minimumTotal:null,totalIsExact:false,page,limit,hasNext,iranianSearch:iranian,sources:{audius:aud.available,jamendo:jam.available,freesound:false}});
};
